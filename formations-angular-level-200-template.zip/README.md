# formations-angular-level-200-template
Template of the project to work on training course level 200
