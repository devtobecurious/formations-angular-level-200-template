export const api = {
  games: {
    url: 'games'
  }
};
