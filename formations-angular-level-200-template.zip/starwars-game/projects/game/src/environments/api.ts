export const api = {
  games: {
    url: 'api/games'
  }
};
