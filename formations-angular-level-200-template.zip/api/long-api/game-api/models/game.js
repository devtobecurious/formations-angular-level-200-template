class Game {
    constructor(id, title, success = true) {
        this.id = id;
        this.title = title
        this.success = success;
    }
} 

module.exports = Game;